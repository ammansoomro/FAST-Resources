﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "EmployeeService" in code, svc and config file together.
public class EmployeeService : IEmployeeService
{

    public string Greetings(string name)
    {
        return "Hello " + name;
    }

    public string HelloWorld(string something)
    {
        throw new NotImplementedException();
    }
}
