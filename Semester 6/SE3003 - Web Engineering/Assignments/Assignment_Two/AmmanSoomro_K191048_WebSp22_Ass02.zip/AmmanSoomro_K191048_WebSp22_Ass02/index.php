<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Index</title>
      <link rel="stylesheet" href="style.css">
   </head>
   <body>
      <div class="container">
        <div class="form">
            <h2>K191048 Index</h2>
            <a href="Task01/Task01_Form.php"><button>Task 01</button></a>
            <a href="Task02/Task02_LocalDataBase.html"><button>Task 02</button></a>
            <a href="Task03/Task03_BillGenerator.php"><button>Task 03</button></a>
            <a href="Task04/Task04_Calculator.php"><button>Task 04</button></a>
        </div>
      </div>
   </body>
</html>