package Task01;
import java.awt.event.ActionListener;
import java.awt.event.MouseMotionListener;
import javax.swing.*;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class View extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame frame;
	JButton Btn_IncreaseSize, Btn_DecreaseSize,Btn_ColorSelector,Btn_Clear,Btn_Erase;
	Canvas canvas;
	JLabel label;
	Color Color_Selected = Color.white;
	JColorChooser ColorPanel;
	Graphics graphic_Var;

	View()
	{
		frame = new JFrame();
		frame.setBounds(200, 200, 900, 500);
        
		canvas = new Canvas();
        canvas.setBounds(40, 50, 810, 300);
        canvas.setBackground(Color.black);
        frame.add(canvas);
        
        label = new JLabel("Draw Here");
        label.setBounds(400, 5, 200, 40);
        label.setFont(new Font("Serif", Font.BOLD, 30));
        frame.add(label);
		
        Btn_IncreaseSize = new JButton();
		Btn_IncreaseSize.setBounds(310, 400, 80, 30);
		Btn_IncreaseSize.setIcon(new ImageIcon("C:\\Users\\Amman Soomro\\SCD_Lab-workspace\\SCD_Assignment01\\src\\Task01\\Increase.png"));
		Btn_IncreaseSize.setBackground(Color.white);
		frame.add(Btn_IncreaseSize);
	
		
		Btn_DecreaseSize = new JButton(); 
		Btn_DecreaseSize.setBounds(420, 400, 80, 30);
		Btn_DecreaseSize.setIcon(new ImageIcon("C:\\Users\\Amman Soomro\\SCD_Lab-workspace\\SCD_Assignment01\\src\\Task01\\Decrease.png"));
		Btn_DecreaseSize.setBackground(Color.white);
		frame.add(Btn_DecreaseSize);

		
		Btn_ColorSelector = new JButton("Color");
		Btn_ColorSelector.setBounds(350, 360, 100, 30);
		Btn_ColorSelector.setIcon(new ImageIcon("C:\\Users\\Amman Soomro\\SCD_Lab-workspace\\SCD_Assignment01\\src\\Task01\\Color_Wheel.png"));
		Btn_ColorSelector.setBackground(Color.white);
		frame.add(Btn_ColorSelector);

		
		Btn_Clear = new JButton("Clear");
		Btn_Clear.setBounds(470, 360, 100, 30);
		Btn_Clear.setIcon(new ImageIcon("C:\\Users\\Amman Soomro\\SCD_Lab-workspace\\SCD_Assignment01\\src\\Task01\\Clear.png"));
		Btn_Clear.setBackground(Color.white);
		frame.add(Btn_Clear);


		Btn_Erase = new JButton();
		Btn_Erase.setBounds(530, 400, 80, 30);
		Btn_Erase.setIcon(new ImageIcon("C:\\Users\\Amman Soomro\\SCD_Lab-workspace\\SCD_Assignment01\\src\\Task01\\Eraser.png"));
		Btn_Erase.setBackground(Color.white);
		frame.add(Btn_Erase);
		
		frame.setLayout(null);
		frame.setVisible(true);
	}
	public void addBtn_ClearListener(ActionListener listenforButton)
	{
		Btn_Clear.addActionListener(listenforButton);
	}
	public void addBtn_ColorSelectorListener(ActionListener listenforButton)
	{
		Btn_ColorSelector.addActionListener(listenforButton);
	}
	public void addBtn_EraseListener(ActionListener listenforButton)
	{
		Btn_Erase.addActionListener(listenforButton);
	}
	public void addBtn_DecreaseSizeListener(ActionListener listenforButton)
	{
		Btn_DecreaseSize.addActionListener(listenforButton);
	}
	public void addBtn_IncreaseSizeListener(ActionListener listenforButton)
	{
		Btn_IncreaseSize.addActionListener(listenforButton);
	}
	public void addMotionCanvasListener(MouseMotionListener listenforCanvas)
	{
        canvas.addMouseMotionListener(listenforCanvas);
	}
	public void setSolution()
	{
		
	}
}
	