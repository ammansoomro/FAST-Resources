package Task01;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JColorChooser;

public class Model {
	private int size = 5;
	private Color Color_Selected;
	public Graphics graphic_Var;
	public Graphics Clear;
	
	public void IncreaseBrushSize(){
		size = size + 5;}
	
	public void DecreaseBrushSize(){
		if(size > 5){				
			size=size-5;}}
	
	public int getSize(){
		return size;}
	
	public void SelectColor(){
		Color new_Color = JColorChooser.showDialog(null,"Select a Color", Color.black); 
		Color_Selected = new_Color;}
	
	public Color getColor(){
		return Color_Selected;}
	
	public Color getEraser(){
		return Color_Selected = Color.black;}

	public Graphics getGraphics(){
		return graphic_Var;}
	
}
