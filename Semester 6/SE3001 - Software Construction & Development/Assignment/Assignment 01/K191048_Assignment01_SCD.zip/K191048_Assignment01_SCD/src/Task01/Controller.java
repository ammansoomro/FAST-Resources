package Task01;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class Controller {
	private View theView;
	private Model theModel;
	public Controller(View theView, Model theModel){
		this.theView = theView;
		this.theModel = theModel;
		this.theView.addBtn_ClearListener(new Btn_ClearListener());
		this.theView.addBtn_ColorSelectorListener(new Btn_ColorSelectorListener());
		this.theView.addBtn_EraseListener(new Btn_EraseListener());
		this.theView.addBtn_IncreaseSizeListener(new Btn_IncreaseSizeListener());
		this.theView.addBtn_DecreaseSizeListener(new Btn_DecreaseSizeListener());
		this.theView.addMotionCanvasListener(new MotionCanvasListener());
	}
	
	class Btn_ClearListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
				theModel.Clear = theView.canvas.getGraphics();
				theModel.Clear.clearRect(0, 0, theView.canvas.getWidth(), theView.canvas.getHeight());}}
	
	class Btn_ColorSelectorListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			theModel.SelectColor();}}
	
	class Btn_EraseListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			theModel.getEraser();}}
	
	class Btn_IncreaseSizeListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			theModel.IncreaseBrushSize();}}
	
	class Btn_DecreaseSizeListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			theModel.DecreaseBrushSize();}}
	
	class MotionCanvasListener implements MouseMotionListener
	{
		@Override
		public void mouseDragged(MouseEvent e) {
			theModel.graphic_Var = theView.canvas.getGraphics();
	        int x, y;
	        theModel.graphic_Var.setColor(theModel.getColor());
	        x = e.getX();
	        y = e.getY();
	        theModel.graphic_Var.fillOval(x, y, theModel.getSize(), theModel.getSize());}
		
		@Override
		public void mouseMoved(MouseEvent e) {}}
	
}