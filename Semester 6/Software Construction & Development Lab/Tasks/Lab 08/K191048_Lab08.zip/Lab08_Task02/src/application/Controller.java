package application;

import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.stage.Stage;

public class Controller {
  private Stage stage;
  private Scene scene;

  public void Scene01(ActionEvent e) throws IOException {
    Parent root = FXMLLoader.load(getClass().getResource("Scene01.fxml"));
    stage = (Stage) (((Node) e.getSource()).getScene().getWindow());
    scene = new Scene(root);
    stage.setScene(scene);
    stage.showAndWait();
  }

  public void Scene02(ActionEvent e) throws IOException {
    Parent root = FXMLLoader.load(getClass().getResource("Scene02.fxml"));
    stage = (Stage) (((Node) e.getSource()).getScene().getWindow());
    scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
  }

  public void PopupWindow(ActionEvent e) throws IOException {
    Parent root = FXMLLoader.load(getClass().getResource("PopupWindow.fxml"));
    Scene scene = new Scene(root);
    Stage stage = new Stage();
    stage.setScene(scene);
    stage.show();
  }
}
